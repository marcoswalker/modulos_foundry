# Licensing

The following fonts are owned by Pixel Sagas, check out their [website](http://www.pixelsagas.com/):

- Barazhad
- Celestial
- Daedra
- Davek
- Dethek
- Espruar
- HighDrowic
- Kargi
- Iokharic
- MageScript
- MarasEye
- OldeEspruar
- OldeThorass
- Ophidian
- Qijomi
- Reanaarian
- Rellanic
- Semphari
- Thorass

The following font was created by TenkaDigi:

- Infernal (Fan Art)

The follow font was created by Helena Jole:

- ScrapbookChinese

The following font was created by Levi:

- Aztec

The following font is under [1001Fonts Free For Personal Use License (FFP)](https://www.1001fonts.com/licenses/ffp.html):

- Dragon Alphabet

The following font is under [GNU GENERAL PUBLIC LICENSE v3](https://www.gnu.org/licenses/gpl-3.0.en.html):

- KremlinPremier

The following font is under [SIL OPEN FONT LICENSE Version 1.1](https://scripts.sil.org/cms/scripts/page.php?item_id=OFL_web):

- [MusiQwik](https://www.fontspace.com/musiqwik-font-f3722). Copyright (c) 2003, Robert Allgeyer.
- [Ny Stormning](https://www.fontspace.com/ny-stormning-font-f23289). Copyright (c) 2016, Mew Too, Robert Jablonski (Cannot Into Space Fonts) (cannotintospacefonts@gmail.com).

The following are under [CC BY-SA 3](https://creativecommons.org/licenses/by-sa/3.0/):

- [Ar Ciela](http://hymmnoserver.uguu.ca/). Hymmnos and HYMMNOSERVER were created by Akira Tsuchiya.
- Elder Futhark FS

The following does not accompanied license terms, were OPL or their license have expired:

- AnglosaxonRunes
- DarkEldar
- Eltharin
- FingerAlphabet
- Floki
- HighschoolRunes
- JungleSlang
- MeroiticDemotic
- MiroslavNormal
- Pulsian (Fan Art by Echiceroo)
- Skaven
- Tengwar (Greifswalder)
- OldeEnglish
- Oriental
- OrkGlyphs
- Thassilonian (Fan Art)
- Tuzluca
- Valmaric